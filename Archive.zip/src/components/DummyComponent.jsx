import React from 'react'

const DummyComponent = ({ text }) => <h1>{text}</h1>

export default DummyComponent
