import dummyReducer from './dummy'

export default {
    dummyReducer,
}
