import { UPDATE_DUMMY_TEXT } from '../types/dummy'
import { actionCreatorUtil } from '../../utils/common'

export const updateDummyText = actionCreatorUtil(UPDATE_DUMMY_TEXT)
