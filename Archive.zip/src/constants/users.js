const users = [
    {
        username: 'love',
        password: 'love@123'
    },
    {
        username: 'trivedi',
        password: 'trivedi@123'
    }
]

export default users
